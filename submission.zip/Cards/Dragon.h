//
// Created by user on 07/06/2022.
//

#ifndef EX4_DRAGON_H
#define EX4_DRAGON_H

#include "Battle.h"

class Dragon : public Battle {

public:

    /**
     * Dragon C'tor
     */
    Dragon();

    /**
     * Default Dragon D'tor
     */
    ~Dragon() = default;

};

#endif //EX4_DRAGON_H
