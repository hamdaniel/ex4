//
// Created by user on 07/06/2022.
//

#include "Goblin.h"

using std::string;
const string GOBLIN_NAME = "Goblin";

Goblin::Goblin() : Battle(GOBLIN_NAME,GOBLIN_FORCE,GOBLIN_DAMAGE,GOBLIN_COINS) {}
